# Exercice router

1. Créer une nouvelle route dont le path est `/users` et qui appelle un composant créé dans ce dossier
2. Afficher les utilisateurs du fichier `data.js` de cet exercice
3. Ajouter un paramètre `ìd` ou `email` à la route et afficher uniquement l'utilisateur concerné
4. Ajoutez un bouton qui renvoie sur l'exercice 1 au clic (et ce, sans lien)
5. Trouvez une autre manière de faire le point 4
6. Ajoutez un bouton qui envoie sur l'utilisateur Anne Trotreau au clic (et ce, sans lien)