export const membres = [
  {
    id: 1,
    firstname: "John",
    lastname: "Doe",
    email: "john.doe@gmail.bzh",
    password: "123456",
    premium: true,
  },
  {
    id: 2,
    firstname: "Jane",
    lastname: "Smith",
    email: "jane.smith@gmail.bzh",
    password: "password",
    premium: false,
  },
  {
    id: 3,
    firstname: "Anne",
    lastname: "Trotreau",
    email: "anne.trotreau@gmail.bzh",
    password: "1234567",
    premium: true,
  },
  {
    id: 4,
    firstname: "Ulrich",
    lastname: "Steiner",
    email: "ulrich.steiner@gmail.bzh",
    password: "securePassword",
    premium: false,
  },
];
